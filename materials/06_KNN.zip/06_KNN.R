###########################################################
#                  Machine Learning 1. labs               #
#              6. KNN - K nearest neighbours              #
#                     Piotr W�jcik                        #
########################################################### 

# let's load needed packages

# install.packages("class") 
library(class)

require(caret)
require(dplyr)

# let's load medical_care data after transformations

load(".../data/medical.RData")

# The file includes socio-demographic data, including 
# health insurance and various aspects of health care
# touchpoints for the respondent group of a survey
# conducted in the USA.

# The collection includes 35072 observations and 29 variables:

# UMARSTAT - Marital status recode
# UCUREMP - Currently has employer coverage
# UCURNINS - Currently uninsured
# USATMED - Satisfied with quality of medical care
# URELATE - Number of relatives in household
# REGION - region
# STATE - state
# HHID - Household identification number
# FHOSP - In hospital overnight last year
# FDENT - Dental visits last year
# FEMER - Number of emergency room visits last year
# FDOCT - Number of doctor visits last year
# UIMMSTAT - Immigration status
# U_USBORN - U.S.- or foreign-born
# UAGE - Age topcoded
# U_FTPT - Full-time or part-time worker this year
# U_WKSLY - Weeks worked last year
# U_HRSLY - Hours worked per week last year
# U_USHRS - Hours worked per week this year
# HEARNVAL - Earnings amount last year - Household
# HOTHVAL - Household income, total exc. earnings
# HRETVAL - Retirement amount - Household
# HSSVAL - Social Security amount - Household
# HWSVAL - Wages and salaries amount - Household
# UBRACE - race
# GENDER - gender
# UEDUC3 - education level
# CEYES - color of eyes
# CHAIR - color of hair


# let's divide our data into training set 
# and testing set as before

set.seed(987654321)

which_train <- createDataPartition(medical$UCURNINS, 
                                   p = 0.7, 
                                   list = FALSE) 

# let's use these indices to divide data into two samples

medical.train <- medical[which_train,]
medical.test <- medical[-which_train,]


#----------------------------------------------
# application of KNN to predict values
# of UCURNINS variable

# we will use a function train() from the caret
# package which in case of KNN method uses
# knn() function from the class package behind

# WARNING! this model requires defining hyperparameters

# list of (hyper)parameters required by a specific model
# can be previewed using the modelLookup() function
# from the caret package

modelLookup("knn")

# model parameter      label forReg forClass probModel
#   knn         k #Neighbors   TRUE     TRUE      TRUE

# here only k - #Neighbors

# however the function knn() has a default value
# of k = 5, so we can run model training without
# setting this parameter

# let's save a model formula as a separate
# object 

model_formula <- UCURNINS ~ UMARSTAT + USATMED + URELATE + REGION + 
  FHOSP + FDENT + FEMER + FDOCT + UIMMSTAT + 
  UAGE + U_FTPT + U_WKSLY + U_USHRS + 
  HOTHVAL + HRETVAL + HSSVAL + HWSVAL + 
  UBRACE + UEDUC3 + GENDER

# and apply knn algorithm on training dataset

# we define appropriate control

ctrl_nocv <- trainControl(method = "none")

# and run the train() function

UCURNINS.train.knn1 <- 
  train(model_formula, 
        data = medical.train, 
        method = "knn",
        trControl = ctrl_nocv)

UCURNINS.train.knn1

# the default parameter value in this case is 5

# it is saved in the "finalModel" element
# results of train()

UCURNINS.train.knn1$finalModel$k

# if we want to set another value of k, we have
# to create a data frame with a column called
# like the parameter and specify one (or more values)

# let's check K = sqrt(n)

sqrt(nrow(medical.train))

# is quite a lot and calculations would 
# be time-consuming
# let's limit ourselves to 50

k_value <- data.frame(k = 50)

# and then use this information
# in the train() function with the option
# tuneGrid=
# WARNING! if we do NOT use re-sampling
# specify ONE parameter (one set of parameters!

UCURNINS.train.knn50 <- 
  train(model_formula, 
        data = medical.train, 
        method = "knn",
        trControl = ctrl_nocv,
        # we give the parameter(s)
        # required by model
        tuneGrid = k_value)

UCURNINS.train.knn50$finalModel$k

# let's calculate fitted values - prediction on the training sample

UCURNINS.knn.fitted50 <- predict(UCURNINS.train.knn50,
                                 medical.train)

# it takes a while - prediction is time-consuming
# for knn

# Let's see the structure of fitted values

table(UCURNINS.knn.fitted50)

# almost all observations qualified as No !!

# check the classification table and accuracy measures

confusionMatrix(data = UCURNINS.knn.fitted50, 
                reference = medical.train$UCURNINS, 
                positive = "Yes")

# accuracy seemingly high but in fact only "failures"
# predicted well (very high specificity)

# let's compare prediction results in the test sample

UCURNINS.knn.forecasts50 <- predict(UCURNINS.train.knn50,
                                    medical.test)

table(UCURNINS.knn.forecasts50)

# our model predicts almost exclusively "failures" - values "No"

confusionMatrix(data = UCURNINS.knn.forecasts50,
                reference = medical.test$UCURNINS, 
                positive = "Yes")

# Specificity = 1, but Sensitivity = 0
# high Accuracy : 0.8556 is misleading
# Balanced Accuracy : 0.5000 is a better measure here


# this classification result is probably the result
# assuming too many closest neighbors

# let's compare the results for k = 5

k_value <- data.frame(k = 5)

UCURNINS.train.knn5 <-
  train(model_formula, 
        data = medical.train, 
        method = "knn",
        trControl = ctrl_nocv,
        tuneGrid = k_value)


# let's calculate fitted values - prediction on the training sample

UCURNINS.knn.fitted5 <- predict(UCURNINS.train.knn5,
                                medical.train)

# Let's see the structure of fitted values

table(UCURNINS.knn.fitted5)

# slightly better than before - some "Yes" predicted

# check the classification table and accuracy measures

confusionMatrix(data = UCURNINS.knn.fitted5, 
                reference = medical.train$UCURNINS,
                positive = "Yes")

# accuracy measures improved

# let's compare prediction results in the test sample

UCURNINS.knn.forecasts5 <- predict(UCURNINS.train.knn5,
                                   medical.test)

table(UCURNINS.knn.forecasts5)

confusionMatrix(data = UCURNINS.knn.forecasts5,
                reference = medical.test$UCURNINS, 
                positive = "Yes")

# there is no improvement of overall accuracy 
# in the test sample...
# 0.8432 is BELOW No Information Rate : 0.8556

# this can be a problem of overfitting
# - small k causes a larger fit to data

# let's try to find optimal value of k

# we will use cross validation for tuning model parameters

# we need to assume a set of different values of k
# and analyze model performance for each parameter value

# CAUTION !!
# due to time consuming prediction of knn, let's limit the 
# training sample to 20% of its observations, selecting 
# a random (stratified) sample from it

set.seed(987654321)

which_small <- createDataPartition(medical.train$UCURNINS,
                                   p = 0.1,
                                   list = FALSE)

medical.train_small <- medical.train[which_small,]
  
# create a data frame with the values 
# of parameter k from 1 to 50

different_k <- data.frame(k = 1:50)

# define the training control -
# use 5-fold cross validation

ctrl_cv5 <- trainControl(method = "cv",
                         number = 5)

# and run the training
set.seed(987654321)

UCURNINS.train.knn_cv <- 
  train(model_formula,
        # smaller sample
        data = medical.train_small, 
        method = "knn",
        trControl = ctrl_cv5,
        # parameters to be compared
        tuneGrid = different_k)

UCURNINS.train.knn_cv

# accuracy quite weak and equal
# for many values of k

# CAUTION! remember that in the case of knn
# variables should be rescaled to the range [0,1]

# this can be done automatically
# within the train() function

# in the case of cross-validation, data
# transformations will ALWAYS use ONLY the data
# from the TRAINING sample (here 4/5 of the set
# at each stage of validation) and in the test data 
# (1/5) analogous transformations will be used 

# to apply transformations of input data in the
# train() function one should use preProcess = 
# option providing the transformation method

# possible values: "scale", "center", "range", etc.
# (also several together)

# value "range" automatically scales all variables
# to range [0, 1]

set.seed(987654321)

UCURNINS.train.knn_cv_scaled <- 
  train(model_formula,
        # smaller sample
        data = medical.train_small, 
        method = "knn",
        trControl = ctrl_cv5,
        # parameters to be compared
        tuneGrid = different_k,
        # data transformation
        preProcess = c("range"))


UCURNINS.train.knn_cv_scaled

# here the best accuracy obtained for 
# k = 18  (0.8623814  )


# let's check which value of k gives the
# highest AUC

ctrl_cv5a <- trainControl(method = "cv",
                          number = 5,
                          classProbs = TRUE,
                          summaryFunction = twoClassSummary)

set.seed(987654321)

UCURNINS.train.knn_cv_scaled2 <- 
  train(model_formula,
        # smaller sample
        data = medical.train_small, 
        method = "knn",
        trControl = ctrl_cv5a,
        # parameters to be compared
        tuneGrid = different_k,
        # metric used to find optimal k
        metric = "ROC",
        # data transformation
        preProcess = c("range"))


UCURNINS.train.knn_cv_scaled2

# from the perspective of of AUC
# the best value of k = 47 (0.7577837)

#----------------------------------------------

# Let's have a look how does it work on a bit more balanced data...
tags = medical$UCURNINS == "Yes"
medical.balanced = rbind(medical[tags,], medical[!tags, ][sample(sum(!tags), sum(tags)),])

which_train <- createDataPartition(medical.balanced$UCURNINS, 
                                   p = 0.7, 
                                   list = FALSE) 

# let's use these indices to divide data into two samples

medical.balanced.train <- medical.balanced[which_train,]
medical.balanced.test <- medical.balanced[-which_train,]

# As before, we fit model of k-neigbs.

k_value <- data.frame(k = 5)
ctrl_nocv <- trainControl(method = "none")

UCURNINS.balanced.train.knn5 <-
  train(model_formula, 
        data = medical.balanced.train, 
        method = "knn",
        trControl = ctrl_nocv,
        tuneGrid = k_value,
        preProcess = c("range")) # <- We are doing pre-processing here!

# let's calculate fitted values - prediction on the training sample

UCURNINS.balanced.knn.fitted5 <- predict(UCURNINS.balanced.train.knn5,
                                medical.balanced.train)

# Let's see the structure of fitted values

table(UCURNINS.balanced.knn.fitted5)

# slightly better than before - some "Yes" predicted

# check the classification table and accuracy measures

confusionMatrix(data = UCURNINS.balanced.knn.fitted5, 
                reference = medical.balanced.train$UCURNINS,
                positive = "Yes")

# accuracy measures improved

# let's compare prediction results in the test sample

UCURNINS.balanced.knn.forecasts5 <- predict(UCURNINS.balanced.train.knn5,
                                   medical.balanced.test)

table(UCURNINS.balanced.knn.forecasts5)

confusionMatrix(data = UCURNINS.balanced.knn.forecasts5,
                reference = medical.balanced.test$UCURNINS, 
                positive = "Yes")

ctrl_cv5b <- trainControl(method = "cv",
                          number = 5,
                          classProbs = TRUE,
                          summaryFunction = twoClassSummary)

# Let's do some cross-validation.

set.seed(987654321)

different_k <- data.frame(k = seq(1, 101, 10))

UCURNINS.balanced.train.knn_cv_scaled2 <- 
  train(model_formula,
        # smaller sample
        data = medical.balanced.train, 
        method = "knn",
        trControl = ctrl_cv5b,
        # parameters to be compared
        tuneGrid = different_k,
        # metric used to find optimal k
        metric = "ROC",
        # data transformation
        preProcess = c("range"))

UCURNINS.balanced.train.knn_cv_scaled2

UCURNINS.balanced.knn.knn_cv_scaled2 <- 
  predict(UCURNINS.balanced.train.knn_cv_scaled2, medical.balanced.test)

table(UCURNINS.balanced.knn.knn_cv_scaled2)

# If we use the best fit, then...
# it seems that using k=71 makes improvement (but not so much).
# And don't forget about normalization.
# After all, we get better fit not only in the train, but also in the test sample.

confusionMatrix(data = UCURNINS.balanced.knn.knn_cv_scaled2,
                reference = medical.balanced.test$UCURNINS, 
                positive = "Yes")

#----------------------------------------------
# Exercises 6

# Exercise 6.1
# Import titanic dataset, divide it into training and test data.
# Apply the KNN method to predict the value of the variable 'survived',
# test a few values of parameter k.
# Check whether the rescaling of variables allows to get
# better forecasts in the test sample.




# Exercise 6.2
# Find the optimal value for the parameter k using
# cross validation.




# Exercise 6.3
# Calculate the prediction error on the train and test sample
# for k = 1, 2, .... 100, and plot results.
# What conclusions can be drawn from this result?



