###########################################################
#                  Machine Learning 1. labs               #
#                    8. Feature selection                 #
#                     Piotr W�jcik                        #
########################################################### 

# let's load needed packages

install.packages("gmodels")
library(gmodels)

install.packages("vcd") # for assocstats
library(vcd)

install.packages("FSelector")
library(FSelector)

install.packages("corrplot")
library(corrplot) 
library(caret)
library(dplyr)
library(MASS)
library(tibble)

# let's load medical_care data after transformations

load(".../data/medical.RData")

# The file includes socio-demographic data, including 
# health insurance and various aspects of health care
# touchpoints for the respondent group of a survey
# conducted in the USA.

# The collection includes 35072 observations and 27 variables:

# UMARSTAT - Marital status recode
# UCUREMP - Currently has employer coverage
# UCURNINS - Currently uninsured
# USATMED - Satisfied with quality of medical care
# URELATE - Number of relatives in household
# REGION - region
# STATE - state``
# HHID - Household identification number
# FHOSP - In hospital overnight last year
# FDENT - Dental visits last year
# FEMER - Number of emergency room visits last year
# FDOCT - Number of doctor visits last year
# UIMMSTAT - Immigration status
# U_USBORN - U.S.- or foreign-born
# UAGE - Age topcoded
# U_FTPT - Full-time or part-time worker this year
# U_WKSLY - Weeks worked last year
# U_HRSLY - Hours worked per week last year
# U_USHRS - Hours worked per week this year
# HEARNVAL - Earnings amount last year - Household
# HOTHVAL - Household income, total exc. earnings
# HRETVAL - Retirement amount - Household
# HSSVAL - Social Security amount - Household
# HWSVAL - Wages and salaries amount - Household
# UBRACE - race
# GENDER - gender
# UEDUC3 - education level
# CEYES - color of eyes
# CHAIR - color of hair

# let's divide our data into training set 
# and testing set as before

set.seed(987654321)

which_train <- createDataPartition(medical$UCURNINS, 
                                   p = 0.7, 
                                   list = FALSE) 

# let's use these indices to divide data into two samples

medical.train <- medical[which_train,]
medical.test <- medical[-which_train,]

#----------------------------------------------
# application to predict values of UCURNINS variable

# let's save a model formula as a separate object 

model_formula <- UCURNINS ~ UMARSTAT + USATMED + URELATE + REGION + 
  FHOSP + FDENT + FEMER + FDOCT + UIMMSTAT + 
  UAGE + U_FTPT + U_WKSLY + U_USHRS + U_HRSLY +
  HOTHVAL + HRETVAL + HSSVAL + HWSVAL + 
  UBRACE + UEDUC3 + GENDER


# let's create separate objects including
# a vector of potential predictors by type

categorical_vars <- c("UMARSTAT", "USATMED", "URELATE",
                      "REGION", "FHOSP", "UIMMSTAT",
                      "U_FTPT", "UBRACE", "UEDUC3",
                      "GENDER")

continuous_vars <- c("FDENT", "FEMER", "FDOCT", "UAGE",
                     "U_WKSLY", "U_USHRS", "U_HRSLY",
                     "HOTHVAL", "HRETVAL", "HSSVAL", "HWSVAL")

#-----------------------------------------------------
# let's initially analyze potential predictors
# of the value of UCURNINS

# for qualitative variables let's print cross frequencies
# using CrossTable() function from the package gmodels
# (it shows both counts and percentages)

# UMARSTAT
CrossTable(medical.train$UMARSTAT,
           medical.train$UCURNINS)

# for simplicity we can turn off unneeded numbers:
# - Chi-square contribution
# - N / Col Total
# - N / Table Total
# leaving only: N and N / Row Total

# We can also test for independence with the Chi-square test

table1 <- CrossTable(medical.train$UMARSTAT,
                     medical.train$UCURNINS,
                     prop.c = F, # no col percentages
                     prop.t = F, # no total percentages
                     prop.chisq = F, # no chi-sq contribution
                     chisq = T) # chi square test shown

# UMARSTAT seems to differentiate the UMARSTAT
# distribution

# relationships between categorical variables
# can be identified with the chi2 test and 
# Cramer's V

# if one wants to get chi2 results
# together with association statistics
# (including V Cramer) it is better
# to use assocstats()
# function from vcd package

# it requires contingency table as input

(chi2 <- assocstats(table(medical.train$UMARSTAT,
                          medical.train$UCURNINS)))

# values of Cramer's V for all
# variables can be obtained
# with the function chi.squared()
# from the FSelector package

(chi2_weights <- chi.squared(UCURNINS ~ ., # simplified model formula
                             # all variables used as predictors
                             # but on a dataset limited to target 
                             # and categorical variables
                             medical.train[,c("UCURNINS", 
                                              categorical_vars)]))

# The result is equal to Cramer's V coefficient 
# between source attributes and destination attribute.

# we can easily select top k variables
# with the highest Cramer's V using
# cutoff.k() function from FSelector

cutoff.k(chi2_weights, k = 5)


# similarly one can calculate 
# information gain (mutual information)
# with another function from FSelector package

# let's do it for all variables (categorical and continuous)

(mutualinfo_weights <- information.gain(model_formula,
                                        medical.train))

# select top 10

cutoff.k(mutualinfo_weights, k = 10)


# for quantitative/continuous variables we may 
# also compare if their mean value differs 
# for insured and uninsured in the ANOVA framework

# let's see an example - aov() from stats package

test_anova <- aov(UAGE ~ UCURNINS,
                  data = medical.train)

summary(test_anova)

# let's see how to extract the value of the test statistic

str(summary(test_anova))

summary(test_anova)[[1]]

# F statistic
summary(test_anova)[[1]][1, 4]

# p-value
summary(test_anova)[[1]][1, 5]

# the alternative version of the test
# is provided by the anovaScores() function

anovaScores(x = medical.train$UAGE,
            y = medical.train$UCURNINS)

# we can then apply this for a list of variables

test_anova2 <- sapply(medical.train[,c(continuous_vars)],
                      function(x) anovaScores(x,
                               medical.train[["UCURNINS"]]))


#---------------------------------------------
# filtering of variables to classification model
# based on the area under ROC curve

# filterVarImp() from caret package

# syntax:
# filterVarImp(x = matrix_with_independent_vars,
#              y = target_variable)


# CAUTION!
# AUC is calculated for EACH level of the target variable!
# for a bivariate target this values are identical
# for both levels

# let's see the example
importance_ROC <-
  filterVarImp(x = medical.train[, c(continuous_vars,
                                     categorical_vars)], 
               y = medical.train$UCURNINS)

importance_ROC

# we can add rownames as a new column
# and sort results by "Yes"

importance_ROC %>% 
  # add rownames as a new column
  rownames_to_column("variable") %>% 
  # exclude column called No
  select(-No) %>% 
  # sort by Yes in descending order
  arrange(desc(Yes))


# Similarly, we can do filtering of variables
# for the regression problem

# In this case, the default measure
# is the absolute value of the t statistic
# in the model with one variable (each separately)


#--------------------------------------------------------
# for continuous variables (dependent and independent) 
# one can use an algorithm that finds importance of attributes 
# basing on their correlation with continuous class attribute

# two more useful functions from the FSelector package

# Pearson's correlation
linear.correlation(U_USHRS ~ FDENT + FEMER + FDOCT + 
                     UAGE + U_WKSLY + U_HRSLY + HOTHVAL +
                     HRETVAL + HSSVAL + HWSVAL,
                   medical.train[, c("UAGE", "U_WKSLY", "U_USHRS",
                                     "U_HRSLY", "FDENT", "FEMER", "FDOCT",
                                     "HOTHVAL", "HRETVAL", "HSSVAL",
                                     "HWSVAL")])

# Spearman's correlation
rank.correlation(U_USHRS ~ FDENT + FEMER + FDOCT + 
                   UAGE + U_WKSLY + U_HRSLY + HOTHVAL +
                   HRETVAL + HSSVAL + HWSVAL,
                 medical.train[, c("UAGE", "U_WKSLY", "U_USHRS",
                                  "U_HRSLY", "FDENT", "FEMER", "FDOCT",
                                   "HOTHVAL", "HRETVAL", "HSSVAL",
                                   "HWSVAL")]) 

# information gain (mutual information)
# can also be calculated for a numeric target

information.gain(U_USHRS ~ FDENT + FEMER + FDOCT + 
                   UAGE + U_WKSLY + U_HRSLY + HOTHVAL +
                   HRETVAL + HSSVAL + HWSVAL,
                 medical.train[, c("UAGE", "U_WKSLY", "U_USHRS",
                                   "U_HRSLY", "FDENT", "FEMER", "FDOCT",
                                   "HOTHVAL", "HRETVAL", "HSSVAL",
                                   "HWSVAL")])


#---------------------------------------------------
# variables with zero or near zero variance

# to identify low-varying variables one can use
# the measure that is the ratio of the most common
# and the second most frequent value ("frequency ratio")

# for diversified variables it will take the value close to 1,
# and a very large value for unbalanced unbalanced

# the next measure is "percent of unique values":
# 100 * (number of unique values) / (number of cases)
# close to zero for little different data

# if the "frequency ratio" is greater than some threshold,
# and "percent of unique values" is less than a certain limit
# one can assume that the variable has a variance close to 0

# to identify such variables we can use the function
# nearZeroVar(data, saveMetrics = FALSE)
# from the caret package

# argument saveMetrics = TRUE will show 
# the details of the calculation

nearZeroVar(medical.train,
            saveMetrics = TRUE)

# while the default value FALSE displays
# only indexes of problematic variables

nearZeroVar(medical.train)

# in our case we have two problematic variables:
# HRETVAL and HSSVAL

# perhaps we should omit them 
# or transform into categorical

prop.table(table(medical.train$HRETVAL == 0))

# 92% of zeroes

prop.table(table(medical.train$HSSVAL == 0))

# 81% of zeroes


#---------------------------------------------------
# mutually correlated (irrelevant) variables

# we can calculate correlations between 
# variables to identify redundant features
# (not always necessary - some methods are robust 
# to multicollinearity)

(corrs <-  cor(medical.train[, continuous_vars]))

# in case of many variables table may be noy readable 
# it is worth to look at graphical representation
# of correlation matrix

# there is a useful function corrplot() from
# a package with the same name - it requires 
# a correlation matrix as input data

# by default it shows a graph with colored dots
# - their size and color saturation indicates
# value of correlation

corrplot(corrs)

# alternatively one can use pie plots

corrplot(corrs, method = "pie")

# available values of the method:
# "circle" (default), "square", "ellipse", 
# "number", "pie", "shade" and "color".


# or a mixed plot - showing correlations
# in two different ways - differently below
# and above the diagonal
# to obtain this we should use corrplot.mixed()

corrplot.mixed(corrs,
               upper = "pie", 
               lower = "number")

# clearly variable U_HRSLY is a candidate to be removed
# from the model - strongly correlates with U_USHRS
# and is less current - refers to "last year"


# the alternative from the caret package:
# findCorrelation(x = correlation_matrix, cutoff = 0.9)
# which identifies correlations above the accepted threshold
# and indicates variables to be deleted

findCorrelation(corrs,
                cutoff = 0.75)

# by default it returns a list of
# column numbers to be deleted

# with the names=TRUE option it returns 
# the list names of correlated columns

findCorrelation(corrs,
                cutoff = 0.75,
                names = TRUE)

#-------------------------------------------------------------
# wrapper methods for estimating models

# caret package enables the use of wrapper methods
# at the model training stage exactly in the same
# way we saw before

# the train() function requires the appropriate method

# let's limit the training sample to about 2000
# observations, selecting a random (stratified)
# sample from it

set.seed(987654321)

which_small <- createDataPartition(medical.train$UCURNINS,
                                   p = 0.0814, # about 8% of original train
                                   list = FALSE)

medical.train_small <- medical.train[which_small,]


# and see the example of backward elimination
# applied to logistic regression

# method = "glmStepAIC"

# here the criterion for adding or removing
# a variable is the AIC information criterion

ctrl_nocv <- trainControl(method = "none")

medical.logit_backward <- 
  train(model_formula,
        data = medical.train_small, 
        # stepwise method
        method = "glmStepAIC",
        # additional argument
        direction = "backward", 
        trControl = ctrl_nocv)

# tracing might be turned off with
# an additional option trace = FALSE

summary(medical.logit_backward)

# analogously method = "lmStepAIC" 
# applies stepwise linear regression

#-------------------------------------------
# forward selection for logistic regression
# choose a model by AIC in a Stepwise Algorithm
# can make this BIC with k argument
fullModel <- glm(model_formula, medical.train_small, family = binomial)
justIntercept <- glm(UCURNINS ~ 1, medical.train_small, family = binomial)

fwds <- step(justIntercept, direction = "forward", 
     scope = list(upper = fullModel, lower = justIntercept))

summary(fwds)
round(exp(fwds$coefficients), 4)
round(exp(confint(fwds)), 4)


# What's better, forward or backward?
bwds <- step(fullModel, direction = "backward")

# Not every variable was picked up!
dim(medical.train)
#-------------------------------------------
# Exercises 8

# based on churn.csv

# The raw data contains 7043 rows (customers) 
# and 21 columns (features)

# The "Churn" column is our target.
# missing values were filled with a median

# customerID
# gender (female, male)
# SeniorCitizen - Whether the customer is a senior citizen or not 
#    (1, 0)
# Partner - Whether the customer has a partner or not 
#    (Yes, No)
# Dependents - Whether the customer has dependents or not 
#    (Yes, No)
# tenure - Number of months the customer has stayed with the company
# PhoneService - Whether the customer has a phone service or not
#    (Yes, No)
# MultipleLines - Whether the customer has multiple lines or not 
#    (Yes, No, No phone service)
# InternetService - Customer's internet service provider
#    (DSL, Fiber optic, No)
# OnlineSecurity - Whether the customer has online security or not 
#    (Yes, No, No internet service)
# OnlineBackup - Whether the customer has online backup or not 
#    (Yes, No, No internet service)
# DeviceProtection - Whether the customer has device protection or not 
#    (Yes, No, No internet service)
# TechSupport - Whether the customer has tech support or not 
#    (Yes, No, No internet service)
# streamingTV - Whether the customer has streaming TV or not
#    (Yes, No, No internet service)
# streamingMovies - Whether the customer has streaming movies or not 
#    (Yes, No, No internet service)
# Contract - The contract term of the customer
#    (Month-to-month, One year, Two year)
# PaperlessBilling - Whether the customer has paperless billing or not
#    (Yes, No))
# PaymentMethod - The customer's payment method
#    (Electronic check, 
#     Mailed check, Bank transfer (automatic), 
#     Credit card (automatic))
# MonthlyCharges - The amount charged to the customer monthly - numeric
# TotalCharges - The total amount charged to the customer - numeric
# Churn - Whether the customer churned or not
#   (Yes or No)
                                                          

# Exercise 8.1
# Import the data from data/churn.csv and 
# check the existence of zero-variance and
# near-zero variabce variables




# Exercise 8.2
# Check correlations between variables




# Exercise 8.3
# Starting from some general model try
# automatic selection of variables
# using different filtering approaches
# (supervised and unsupervised)




# Exercise 8.4
# Run logistic regression with backward
# elimination of variables. Save the final model.




# Exercise 8.5
# Compare the predictive accuracy 
# on the test sample for logistic regression 
# models including:
# - all sensible variables (w/o redundant and
#   irrelevant features)
# - variables left after backward elimination
# - top 3 categorical and top 3 continuous variables




