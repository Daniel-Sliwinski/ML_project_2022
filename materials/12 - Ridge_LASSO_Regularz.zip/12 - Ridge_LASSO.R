###########################################################
#                  Machine Learning 1. labs               #
#         Regularization: Ridge and LASSO regression      #
#                     Piotr W�jcik                        #
###########################################################

# let's load needed packages
rm(list = ls())
setwd(".../pythonMLDS")

library(caret)

install.packages("glmnet")
library(glmnet)
library(dplyr)

# let's load medical_care data after transformations.

load(".../pythonMLDS/data/medical.RData")

# The file includes socio-demographic data, including 
# health insurance and various aspects of health care
# touchpoints for the respondent group of a survey
# conducted in the USA.

# The collection includes 35072 observations and 27 variables:

# UMARSTAT - Marital status recode
# UCUREMP - Currently has employer coverage
# UCURNINS - Currently uninsured
# USATMED - Satisfied with quality of medical care
# URELATE - Number of relatives in household
# REGION - region
# STATE - state``
# HHID - Household identification number
# FHOSP - In hospital overnight last year
# FDENT - Dental visits last year
# FEMER - Number of emergency room visits last year
# FDOCT - Number of doctor visits last year
# UIMMSTAT - Immigration status
# U_USBORN - U.S.- or foreign-born
# UAGE - Age topcoded
# U_FTPT - Full-time or part-time worker this year
# U_WKSLY - Weeks worked last year
# U_HRSLY - Hours worked per week last year
# U_USHRS - Hours worked per week this year
# HEARNVAL - Earnings amount last year - Household
# HOTHVAL - Household income, total exc. earnings
# HRETVAL - Retirement amount - Household
# HSSVAL - Social Security amount - Household
# HWSVAL - Wages and salaries amount - Household
# UBRACE - race
# GENDER - gender
# UEDUC3 - education level
# CEYES - color of eyes
# CHAIR - color of hair

# let's divide our data into training set 
# and testing set as before
set.seed(987654321)
which_train <- createDataPartition(medical$U_USHRS, 
                                    p = 0.7, 
                                    list = FALSE) 

# let's use these indices to divide data into two samples

medical.train <- medical[which_train,]
medical.test <- medical[-which_train,]

# We will use function glmnet() from glmnet package
# (Friedman, Hastie, and Tibshirani 2008)

# Warning!
# in glmnet() we don't use formulas, but: 
# y = explained var
# x = matrix of explaining vars
# family = kind of target function
#          "gaussian" for linear regression with penalty, 
#          "binomial" for binary classification, with penalized logit regression
#          "multinomial" for classification with more than 2 possible vals of target var, multinominal logit.


# we need to manually decode qualitative vars

options(contrasts = rep("contr.treatment", 2))

medical.train_matrix <- 
  model.matrix(~ UAGE + U_WKSLY + U_HRSLY + HEARNVAL + 
                 HOTHVAL + HRETVAL + HSSVAL + HWSVAL +
                 FDENT + FEMER + FDOCT +
                 # qualitative
                 UMARSTAT + UCUREMP + URELATE + REGION +
                 FHOSP + UIMMSTAT + U_FTPT +
                 UBRACE + GENDER + UEDUC3 + 
                 CEYES + CHAIR,
               medical.train) 

# let's remove constant variable, added before.

medical.train_matrix <- medical.train_matrix[, -1]

# analogously for test data.
medical.test_matrix <- 
  model.matrix(~ UAGE + U_WKSLY + U_HRSLY + HEARNVAL + 
                 HOTHVAL + HRETVAL + HSSVAL + HWSVAL +
                 FDENT + FEMER + FDOCT +
                 # qualitative
                 UMARSTAT + UCUREMP + URELATE + REGION +
                 FHOSP + UIMMSTAT + U_FTPT +
                 UBRACE + GENDER + UEDUC3 + 
                 CEYES + CHAIR,
               medical.test) 

medical.test_matrix <- medical.test_matrix[,-1]

# glmnet() uses only numerical vars

# alpha = 0 means means ridge regression
# alpha = 1 means LASSO

#let's start from ridge.

hours.ridge <- glmnet(x = medical.train_matrix,
                      y = medical.train$U_USHRS,
                      family = "gaussian", # function will 'guess' based on y var character
                      alpha = 0)

# let's see default set of lambdas.

hours.ridge$lambda

# let's use own lambdas
# 500 values between 10^(-5) and 10^10
# so, from close to 0 (almost common regression)
# up to very strong punishment for beta coefficients.

lambdas <- 10 ^ seq(-5, 10, length = 500)
hours.ridge <- glmnet(x = medical.train_matrix,
                      y = medical.train$U_USHRS,
                      family = "gaussian",
                      lambda = lambdas,
                      alpha = 0)

# Warning: glmnet() standardizes vars by default,
# so the have common scale (we can switch off with standardize = FALSE).

# for every lambda we have a set of coefficients.
dim(coef(hours.ridge))

# We expect that for greater lambdas coeffs will be closer to 0.
# let's see (remember, they come from biggest to lowest values), do
# let's start from 490th.

hours.ridge$lambda[490]
# parameter of GENDERMale
coef(hours.ridge)["GENDERMale",490]

# for greatest lambda
hours.ridge$lambda[1]
# parameter of UAGE: very close to zero, but not zero.
coef(hours.ridge)["GENDERMale",1]

# let's make a simple plot.
plot(hours.ridge$lambda[250:500],
     coef(hours.ridge)["GENDERMale",250:500],
     type = "l",
     col = "blue")

# We can use predict() to calculate values of model's parameters for any lambda.

predict(hours.ridge,
        s = 10, # lambda
        type = "coefficients")

# we can also generate fitted values or predictions per requested lambda.

head(predict(hours.ridge, # estimated model
        s = 10, # lambda
        newx = medical.test_matrix))

# we can use cross-validation to get optimal lambda.
# we use cv.glmnet() : by default, it does 10-fold cross-validation (nfolds=)

set.seed(987654321)
hours.ridge.cv <- cv.glmnet(x = medical.train_matrix,
                            y = medical.train$U_USHRS,
                            lambda = lambdas,
                            alpha = 0)
str(hours.ridge.cv)
plot(hours.ridge.cv)

# We got an estimation of mean error and their conf. intervals 
# for every log(lambda).
# Best value lambda (lowest prediction error, based on cross-val).
hours.ridge.cv$lambda.min

# Coeffs are NOT zeros.
predict(hours.ridge, # model
        s = hours.ridge.cv$lambda.min, # lambda
        type = "coefficients")

# Function calculating RMSE for prediction of working hours from model:

RMSE_regularization <- function(model, lambda) {
  prediction <- predict(model, 
                      s = lambda,
                      newx = medical.test_matrix)
  RMSE <- sqrt(mean((medical.test$U_USHRS - prediction)^2))
  return(RMSE)
}

# let's see errors from simple linear regression (lambda = 0).
RMSE_regularization(model = hours.ridge,
                   lambda = 0)

# and for optimal lambda...
RMSE_regularization(model = hours.ridge,
                   lambda = hours.ridge.cv$lambda.min)

# A BIT lower - so despite imposing boundaries, forcing different model than LSM,
# we got better results. Still, penalty for greatness of params is small, 0.0232.

# let's see for lambda = 1
RMSE_regularization(model = hours.ridge,
                   lambda = 1)

# lambda = 10
RMSE_regularization(model = hours.ridge,
                   lambda = 10)

# LASSO.

# We use cross-validation to get optimal lambda value.
set.seed(987654321)
hours.lasso.cv <- cv.glmnet(x = medical.train_matrix,
                            y = medical.train$U_USHRS,
                            lambda = lambdas,
                            alpha = 1) # alpha = 1 for LASSO

# Simple plot. 
plot(hours.lasso.cv)

# What's the best lambda Very close to 0.
hours.lasso.cv$lambda.min

# Let's see the coeffs:
predict(hours.lasso.cv, # model
        s = hours.lasso.cv$lambda.min, # lambda
        type = "coefficients")

# Despite of small lambda, just a few vars dropped out (marked by dots) of the model.

# let's see for bigger lambda:
predict(hours.lasso.cv, # model
        s = 0.1, # lambda
        type = "coefficients")

# Here majority of vars has coeffsequal to zero.

# Let's see the quality of forecast from model with the optimal lambda.
RMSE_regularization(model = hours.lasso.cv,
                   lambda = hours.lasso.cv$lambda.min)

# What did we get in ridge regression?
RMSE_regularization(model = hours.ridge,
                   lambda = hours.ridge.cv$lambda.min)

# LASSO lowered this even more.

#----------------------------------------------------------
# Let's see for logit / multinominal logit.

load(".../pythonMLDS/data/UCURNINS_train_test.RData")

medical.UCURNINS.train_matrix <- 
  model.matrix(~ UMARSTAT + USATMED + URELATE + REGION + 
                 FHOSP + FDENT + FEMER + FDOCT + UIMMSTAT + 
                 UAGE + U_FTPT + U_WKSLY + U_USHRS + 
                 HOTHVAL + HRETVAL + HSSVAL + HWSVAL + 
                 UBRACE + UEDUC3 + GENDER,
               daneusa.UCURNINS.train) 

medical.UCURNINS.train_matrix <- medical.UCURNINS.train_matrix[,-1]

medical.UCURNINS.test_matrix <- 
  model.matrix(~ UMARSTAT + USATMED + URELATE + REGION + 
                 FHOSP + FDENT + FEMER + FDOCT + UIMMSTAT + 
                 UAGE + U_FTPT + U_WKSLY + U_USHRS + 
                 HOTHVAL + HRETVAL + HSSVAL + HWSVAL + 
                 UBRACE + UEDUC3 + GENDER,
               daneusa.UCURNINS.test) 

medical.UCURNINS.test_matrix <- medical.UCURNINS.test_matrix[,-1]

# ridge - let's use cross-validation at once, and limit possible lambdas.
# It will take a few secs.
lambdas2 <- 10^seq(-5, 2, length = 100)

set.seed(987654321)
UCURNINS.ridge <- cv.glmnet(x = medical.UCURNINS.train_matrix,
                            y = daneusa.UCURNINS.train$UCURNINS,
                            family = "binomial",
                            lambda = lambdas2,
                            alpha = 0)

UCURNINS.ridge$lambda.min

# Value is close to 0.
# Simple plot.
plot(UCURNINS.ridge)

# Let's see what we have in the store for binary var.
head(predict(UCURNINS.ridge, # model
             s = UCURNINS.ridge$lambda.min, # lambda
             type = "response",
             newx = medical.UCURNINS.test_matrix))

# Probabilities of 'success'.

# Function to calculate quality of prediction (percent of correct predictions).
accuracy_regularization <- function(model, lambda, cutoff = 0.5) {
  prediction <- predict(model, 
                      s = lambda,
                      type = "response",
                      newx = medical.UCURNINS.test_matrix)
  table <- table(daneusa.UCURNINS.test$UCURNINS,
                    ifelse(as.numeric(prediction) > cutoff, "Yes", "No"))
  accuracy <- sum(diag(table))/sum(table)
  return(accuracy)
}

# Let's see errors from common logit regression (lambda = 0).
accuracy_regularization(model = UCURNINS.ridge,
                       lambda = 0)

# and for the optimal lambda...
accuracy_regularization(model = UCURNINS.ridge,
                   lambda = UCURNINS.ridge$lambda.min)

# Do we think this is an improvement? Rather not.

# And LASSO?
set.seed(987654321)
UCURNINS.lasso <- cv.glmnet(x = medical.UCURNINS.train_matrix,
                            y = daneusa.UCURNINS.train$UCURNINS,
                            family = "binomial",
                            lambda = lambdas2,
                            alpha = 1) # LASSO

# best lambda:
UCURNINS.lasso$lambda.min

# again, close to 0.
# Cross-validation plot.
plot(UCURNINS.lasso)

# Let's see LASSO accuracy on the test sample.
accuracy_regularization(model = UCURNINS.lasso,
                       lambda = UCURNINS.lasso$lambda.min)

# A BIT better result.
accuracy_regularization(model = UCURNINS.lasso,
                       lambda = 0)


# Exercises.

# 1.
# Use ridge and LASSO regression to predict quality of wine.
# Find optimal lambda, check, if you can improve (in test sample) model compared
# to simple linear regression.
wines = read.csv("...data/wines.csv")
set.seed(987654321)
train <- createDataPartition(wines$quality, 
                                    p = 0.7, 
                                    list = FALSE) 
wines.train <- wines[train, ]
wines.test <- wines[-train, ]
wines.train_matrix <- model.matrix( quality - . , wines.train)
wines.train_matrix = wines.train_matrix[, -1]

# 2.
# Use ridge and LASSO regression to predict survival probability on Titanic.
# Find optimal lambda, check, if you can improve (in test sample) model compared
# to simple logit regression.
